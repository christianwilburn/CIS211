#include <iostream>
#include <string>

using namespace std;

// Structure to hold family member data
struct FamilyMember {
    string name;
    string birthCity;
    int birthYear;
};

int main() {
    const int NUM_FAMILY_MEMBERS = 5;
    FamilyMember* familyMembers = new FamilyMember[NUM_FAMILY_MEMBERS]; // Dynamically allocated array of FamilyMember structs

    // Prompt the user to enter data for each family member
    cout << "Enter data for each family member:\n";
    for (int i = 0; i < NUM_FAMILY_MEMBERS; ++i) {
        cout << "\nFamily Member " << i + 1 << ":\n";
        
        // Input name
        cout << "Enter name: ";
        getline(cin, familyMembers[i].name);

        // Input birth city
        cout << "Enter birth city: ";
        getline(cin, familyMembers[i].birthCity);

        // Input birth year
        string birthYearStr;
        int birthYear;
        bool validYear = false;
        while (!validYear) {
            cout << "Enter birth year (in the format 19XX or 20XX): ";
            getline(cin, birthYearStr);
            if (birthYearStr.size() == 4 && birthYearStr[0] == '1' && (birthYearStr[1] == '9' || birthYearStr[1] == '0')) {
                birthYear = stoi(birthYearStr.substr(0, 2));
                validYear = true;
            } else if (birthYearStr.size() == 4 && birthYearStr[0] == '2' && birthYearStr[1] == '0') {
                birthYear = stoi(birthYearStr.substr(0, 2));
                validYear = true;
            } else {
                cout << "Invalid year format. Please enter a valid year.\n";
            }
        }
        familyMembers[i].birthYear = birthYear;
    }

    // Output data in a formatted table
    cout << "\n\nFamily Member Data:\n";
    cout << "----------------------------------------\n";
    cout << "Name\t\tBirth City\tBirth Year\n";
    cout << "----------------------------------------\n";
    for (int i = 0; i < NUM_FAMILY_MEMBERS; ++i) {
        cout << familyMembers[i].name << "\t\t" << familyMembers[i].birthCity << "\t\t" << "19" << familyMembers[i].birthYear << endl;
    }

    // Free dynamically allocated memory
    delete[] familyMembers;

    return 0;
}