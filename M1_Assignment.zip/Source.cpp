#include <iostream>
using namespace std;
int main()
{

	int width;
	cout << "What is the width? \n";
	cin >> width;
	cout << "Width is: \n" << width; 

	int length;
	cout << "\n What is the height? \n";
	cin >> length;
	cout << "Height is: \n" << length;

	int size;
	size = length * width;
	cout << "\n Room size is: \n" << size;
}